package br.pm.business;

public class Professor extends Usuario {
    public Professor(String nome, String matricula) {
        super(nome, matricula, new PoliticaProfessor());
    }
}

