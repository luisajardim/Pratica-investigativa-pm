package br.pm.business;

interface PoliticaEmprestimo {
    int getPrazoMaximoDias();
    double getMultaPorDia();
}